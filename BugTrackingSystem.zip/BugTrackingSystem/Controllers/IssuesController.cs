﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.Entity;
using System.Linq;
using System.Net;
using System.Web;
using System.Web.Mvc;
using BugTrackingSystem.Models;
using System.IO;

namespace BugTrackingSystem.Controllers
{
    public class IssuesController : Controller
    {
       

        private ApplicationDbContext db = new ApplicationDbContext();

        // GET: Issues
      //  [Authorize(Roles = "Yönetici,Developer,SonKullanici")]
        public ActionResult Index()
        {

            var currentUser = db.Users.FirstOrDefault(n => n.UserName == User.Identity.Name);
            return View(db.Issues.Where(n => n.Reporter == currentUser.Name).ToList());
        }

        // GET: Issues/Details/5
       // [Authorize(Roles = "Yönetici,Developer,SonKullanici")]
        public ActionResult Details(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Issue issue = db.Issues.Find(id);
            if (issue == null)
            {
                return HttpNotFound();
            }
            return View(issue);
        }


        // GET: Issues/Create
      //  [Authorize(Roles = "Yönetici,Developer,SonKullanici")]
        public ActionResult Create()
        {
            return View();
        }

        // POST: Issues/Create
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
       // [Authorize(Roles = "Yönetici,Developer,SonKullanici")]
        public ActionResult Create([Bind(Include = "Id,ProjectName,Priority,IssueType,Summary,Description,Reporter")] Issue issue)
        {
            if (ModelState.IsValid)
            {
                issue.Id = db.Issues.Max(c => c.Id) + 1;
                db.Issues.Add(issue);
                issue.EntryDate = DateTime.Now;
                issue.ResolveDate = DateTime.Now;
                    db.SaveChanges();

                return RedirectToAction("Index");
            }

            return View(issue);
        }
        [HttpPost]
      //  [Authorize(Roles = "Yönetici,Developer,SonKullanici")]
        public ActionResult UploadFile(System.Web.HttpPostedFileBase UploadFile)
        {
            if(UploadFile!= null && UploadFile.ContentLength>0)
            {
                UploadFile.SaveAs(Server.MapPath("~/Dosyalar" + UploadFile.FileName));
            }

            return View();
        }
       // [Authorize(Roles = "Yönetici,Developer,SonKullanici")]
        public ActionResult UploadFile()
        {


            return View();
        }
        // GET: Issues/Edit/5
      //  [Authorize(Roles = "Yönetici,Developer,SonKullanici")]
        public ActionResult Edit(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Issue issue = db.Issues.Find(id);
            if (issue == null)
            {
                return HttpNotFound();
            }
            return View(issue);
        }

        // POST: Issues/Edit/5
        // To protect from overposting attacks, please enable the specific properties you want to bind to, for 
        // more details see http://go.microsoft.com/fwlink/?LinkId=317598.
        [HttpPost]
        [ValidateAntiForgeryToken]
      //  [Authorize(Roles = "Yönetici,Developer,SonKullanici")]
        public ActionResult Edit([Bind(Include = "Id,ProjectName,Priority,IssueType,Summary,Description,Reporter")] Issue issue)
        {
            if (ModelState.IsValid)
            {
                db.Entry(issue).State = EntityState.Modified;
                db.SaveChanges();
                return RedirectToAction("Index");
            }
            return View(issue);
        }

        // GET: Issues/Delete/5
      //  [Authorize(Roles = "Yönetici,Developer,SonKullanici")]
        public ActionResult Delete(int? id)
        {
            if (id == null)
            {
                return new HttpStatusCodeResult(HttpStatusCode.BadRequest);
            }
            Issue issue = db.Issues.Find(id);
            if (issue == null)
            {
                return HttpNotFound();
            }
            return View(issue);
        }

        // POST: Issues/Delete/5
        [HttpPost, ActionName("Delete")]
        [ValidateAntiForgeryToken]
       // [Authorize(Roles = "Yönetici,Developer,SonKullanici")]
        public ActionResult DeleteConfirmed(int id)
        {
            Issue issue = db.Issues.Find(id);
            db.Issues.Remove(issue);
            db.SaveChanges();
            return RedirectToAction("Index");
        }

        protected override void Dispose(bool disposing)
        {
            if (disposing)
            {
                db.Dispose();
            }
            base.Dispose(disposing);
        }
    }
}
